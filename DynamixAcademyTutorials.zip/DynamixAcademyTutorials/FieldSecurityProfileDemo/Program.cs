﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace FieldSecurityProfileDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //    string userName = "admin@dynamixacademy20.onmicrosoft.com";
            //    string passWord = "Sooners@2020";


            //string userName = "user1@dynamixacademy20.onmicrosoft.com";
            //string passWord = "Sooners@2021";

            string userName = "user2@dynamixacademy20.onmicrosoft.com";
            string passWord = "Sooners@2022";

            IOrganizationService organizationService = EstablishConnection(userName, passWord);
            if (organizationService != null)
            {

                //SecuredAttributeInColumnSet(organizationService);
                //SecuredAttributeInFilterCondition(organizationService);
                //AggregateOnSecuredAttribute(organizationService);
                //GroupingOnSecuredAttribute(organizationService);
                OrderingOnSecuredAttribute(organizationService);
            }


            Console.ReadKey();
        }

        public static IOrganizationService EstablishConnection(string userName, string passWord)
        {

            IOrganizationService organizationService;
            try
            {
                ClientCredentials clientCredentials = new ClientCredentials();
                clientCredentials.UserName.UserName = userName;
                clientCredentials.UserName.Password = passWord;

                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                // ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                // Get the URL from CRM, Navigate to Settings -> Customizations -> Developer Resources
                // Copy and Paste Organization Service Endpoint Address URL
                organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://dynamixacademy20.api.crm8.dynamics.com/XRMServices/2011/Organization.svc"),
                 null, clientCredentials, null);

                if (organizationService != null)
                {
                    Guid userid = ((WhoAmIResponse)organizationService.Execute(new WhoAmIRequest())).UserId;

                    if (userid != Guid.Empty)
                    {
                        Console.WriteLine("Connection Established Successfully...");
                    }
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");
                }
            }
            catch (Exception ex)
            {
                organizationService = null;
                Console.WriteLine("Exception caught - " + ex.Message);
            }
            return organizationService;
        }

        public static void SecuredAttributeInColumnSet(IOrganizationService _service)
        {
            System.Console.WriteLine("******************* SecuredAttributeInColumnSet - Start *******************");
            string fetch1 = @"  
                            <fetch mapping='logical'>  
                                <entity name='account'>   
                                <attribute name='accountid'/>   
                                <attribute name='name'/>  
                                <attribute name='new_budget'/>  
                                </entity>   
                            </fetch> ";

            EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetch1));
            foreach (var c in result.Entities)
            {
                string accName = c.Attributes["name"].ToString();
                string accBudget = c.Attributes.Contains("new_budget") ? ((Money)c.Attributes["new_budget"]).Value.ToString() : "Budget is NULL";
                System.Console.WriteLine("Account Name: " + accName + " and Budget = " + accBudget);
            }

            System.Console.WriteLine("******************* SecuredAttributeInColumnSet - End *******************");
        }

        public static void SecuredAttributeInFilterCondition(IOrganizationService _service)
        {
            System.Console.WriteLine("******************* SecuredAttributeInFilterCondition - Start *******************");
            string fetch = @"  
                            <fetch mapping='logical'>  
                                <entity name='account'>   
                                    <attribute name='accountid'/>   
                                    <attribute name='name'/>  
                                    <attribute name='new_budget'/>  
                                    <filter type ='and'>
                                        <condition attribute ='new_budget' operator='le' value ='2020'/>
                                    </filter>
                                </entity>   
                            </fetch> ";

            EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetch));
            if (result.Entities.Count > 0)
            {
                foreach (var c in result.Entities)
                {
                    System.Console.WriteLine(c.Attributes["name"]);
                }
            }
            else
            {
                System.Console.WriteLine("No Results Found");
            }

            System.Console.WriteLine("******************* SecuredAttributeInFilterCondition - End *******************");
        }

        public static void AggregateOnSecuredAttribute(IOrganizationService _service)
        {
            System.Console.WriteLine("******************* AggregateOnSecuredAttribute - Start *******************");
            string revenue_avg = @"<fetch distinct='false' mapping='logical' aggregate='true'> 
                                          <entity name='account'> 
                                              <attribute name='new_budget' alias='revenue_avg' aggregate='avg' /> 
                                           </entity> 
                                        </fetch>";

            EntityCollection revenue_avg_result = _service.RetrieveMultiple(new FetchExpression(revenue_avg));

            foreach (var c in revenue_avg_result.Entities)
            {
                string aggregate1 = ((AliasedValue)c["revenue_avg"]).Value != null ? ((Money)((AliasedValue)c["revenue_avg"]).Value).Value.ToString() : "Aggregate is Null";
                System.Console.WriteLine("Average Budget: " + aggregate1);
            }
            System.Console.WriteLine("******************* AggregateOnSecuredAttribute - End *******************");
        }

        public static void GroupingOnSecuredAttribute(IOrganizationService _service)
        {
            System.Console.WriteLine("******************* GroupingOnSecuredAttribute - Start *******************");
            string quotes = @"
                            <fetch distinct ='false' mapping ='logical' aggregate='true'>
                                <entity name ='account'>
                                    <attribute name ='marketcap' alias='marketcap_sum' aggregate='sum'/>
                                    <attribute name ='new_budget' groupby='true' alias='budgetalias'/>
                                    
                                </entity>
                            </fetch>";
            EntityCollection quotes_result = _service.RetrieveMultiple(new FetchExpression(quotes));
            foreach (var q in quotes_result.Entities)
            {
                Decimal totalRevenueAmount = ((Money)((AliasedValue)q["marketcap_sum"]).Value).Value;
                System.Console.WriteLine("Total Budget value: " + totalRevenueAmount);
            }
            System.Console.WriteLine("******************* GroupingOnSecuredAttribute - End *******************");
        }

        public static void OrderingOnSecuredAttribute(IOrganizationService _service)
        {
            System.Console.WriteLine("******************* OrderingOnSecuredAttribute - Start *******************");
            string quotes = @"
                            <fetch mapping='logical'>
                                <entity name='account'>
                                    <attribute name='accountid'/>   
                                    <attribute name='name'/>  
                                    <order attribute='new_budget' descending = 'true'/>
                                </entity>
                            </fetch>";
            EntityCollection quotes_result = _service.RetrieveMultiple(new FetchExpression(quotes));
            foreach (var q in quotes_result.Entities)
            {
                System.Console.WriteLine("Account Name: " + q.Attributes["name"]);
            }
            System.Console.WriteLine("******************* OrderingOnSecuredAttribute - End *******************");
        }
    }
}
