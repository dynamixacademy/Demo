﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using MyOrg;
using System;
using System.Linq;

namespace LateBindingEarlyBinidngDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"AuthType=Office365; Url=https://dynxdev.crm.dynamics.com/;Username=abhi@dynxdev.onmicrosoft.com;Password=Safex12345";
            CrmServiceClient crmServiceClient = new CrmServiceClient(connectionString);

            IOrganizationService organizationService =
               (IOrganizationService)crmServiceClient.OrganizationWebProxyClient != null ? (IOrganizationService)crmServiceClient.OrganizationWebProxyClient : (IOrganizationService)crmServiceClient.OrganizationServiceProxy;

            if (organizationService != null)
            {
                Console.WriteLine("Connection Successful!");
                LateBindingDemo(organizationService);
                //EarlyBindingDemo(organizationService);
              //MixLateAndEarlyBindingDemo(organizationService);
                //MixEarlyAndLateBindingDemo(organizationService);
            }
            else
            {
                Console.WriteLine("Failed to Established Connection!!!");
            }
            Console.ReadLine();
        }

        public static void LateBindingDemo(IOrganizationService service)
        {
            //Use Entity class with entity logical name
            var account = new Entity("account");

            // set attribute values
            // string primary name
            account["name"] = "Contoso";
            // Boolean (Two option)
            account["creditonhold"] = false;
            // DateTime
            account["lastonholdtime"] = new DateTime(2017, 1, 1);
            // Double
            account["address1_latitude"] = 47.642311;
            account["address1_longitude"] = -122.136841;
            // Int
            account["numberofemployees"] = 500;
            // Money
            account["revenue"] = new Money(new decimal(5000000.00));
            // Picklist (Option set)
            account["accountcategorycode"] = new OptionSetValue(1); //Preferred customer

            //Create the account
            Guid accountid = service.Create(account);

            Console.WriteLine("Record Created Succesfully - Late Binding " + accountid);
        }

        public static void EarlyBindingDemo(IOrganizationService service)
        {
            var account = new Account();
            // set attribute values
            // string primary name
            account.Name = "Contoso - Early Binding Demo";
            // Boolean (Two option)
            account.CreditOnHold = false;
            // DateTime
            account.LastOnHoldTime = new DateTime(2017, 1, 1);
            // Double
            account.Address1_Latitude = 47.642311;
            account.Address1_Longitude = -122.136841;
            // Int
            account.NumberOfEmployees = 500;
            // Money
            account.Revenue = new Money(new decimal(5000000.00));
            // Picklist (Option set)
            account.AccountCategoryCode = new OptionSetValue(1); //Preferred customer

            //Create the account
            Guid accountid = service.Create(account);
            Console.WriteLine("Record Created Succesfully - Early Binding " + accountid);
        }

        public static void MixLateAndEarlyBindingDemo(IOrganizationService service)
        {
            //// Create an organization service context object  
            //MyContext context = new MyContext(service);

            //// Instantiate an account object using the Entity class.  
            //Entity testaccount = new Entity("account");

            //// Set several attributes. For account, only the name is required.   
            //testaccount["name"] = "Fourth Coffee";
            //testaccount["emailaddress1"] = "marshd@contoso.com";

            //// Save the entity using the organization service context object.  
            //context.Account(testaccount);
            //context.SaveChanges();
            //Console.WriteLine("Record Created Succesfully - Mix Late And Early Binding Demo " + accountid);
        }

        public static void MixEarlyAndLateBindingDemo(IOrganizationService service)
        {
            //// Create an organization service context object  
            //var account = new Account();
            //// set attribute values
            //// string primary name
            //account.Name = "Contoso";
            //// A  boolean attribute not included in the generated classes.
            //account["creditonhold"] = false;


            ////Create the account
            //Guid accountid = service.Create(account);
            // Console.WriteLine("Record Created Succesfully - Mix Early And Late Binding Demo " + accountid);
        }
    }
}
