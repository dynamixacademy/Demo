﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using System.Net;
using System.ServiceModel.Description;
using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System.Configuration;

namespace ConnectToD365UsingCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            IOrganizationService organizationService = null;

            try
            {
                // ClientCredentials clientCredentials = new ClientCredentials();
                // clientCredentials.UserName.UserName = "admin@dynamixacademy20.onmicrosoft.com";
                // clientCredentials.UserName.Password = "knkmnbwdwzypccxp";

                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;


                // Get the URL from CRM, Navigate to Settings -> Customizations -> Developer Resources
                // Copy and Paste Organization Service Endpoint Address URL                       
                // organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://dynx2020.api.crm8.dynamics.com/XRMServices/2011/Organization.svc"),
                // null, clientCredentials, null);
                //CrmConnection crmConnection = CrmConnection.Parse("Url=http://crm/beta; Domain=MyDomainName; Username=Administrator; Password=MyPassword;");
                //OrganizationService service = new OrganizationService(crmConnection);

                // string connectionString = "AuthType=ClientSecret; url=https://dynx2020.crm8.dynamics.com/; ClientId=da371d11-5940-4198-baa7-356382102cf3; ClientSecret=5tyULF2X-v_4V.Laq5WgrtOPUfJ2~V2We.";

                //string connectionString = ConfigurationManager.ConnectionStrings["D365Mfa"].ConnectionString;
               //CrmServiceClient crmServiceClient = new CrmServiceClient(connectionString); //Connecting to the D-365 CE instance

                string connectionString = @"AuthType=Office365; Url=https://dynx2020.crm8.dynamics.com/;Username=admin@dynx2020.onmicrosoft.com;Password=knkmnbwdwzypccxp";
                CrmServiceClient crmServiceClient = new CrmServiceClient(connectionString);



                // IOrganizationService service;
                organizationService = (IOrganizationService)crmServiceClient.OrganizationWebProxyClient != null ? (IOrganizationService)crmServiceClient.OrganizationWebProxyClient : (IOrganizationService)crmServiceClient.OrganizationServiceProxy;


                if (organizationService != null)
                {
                    Console.WriteLine("Connection Successful!");
                    RetriveContact(organizationService);
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught - " + ex.Message);
            }
            Console.ReadKey();
        }

        public static void RetriveContact(IOrganizationService _service)
        {

            string fetch = @"  
                            <fetch mapping='logical'>  
                                <entity name='contact'>   
                                    <attribute name='contactid'/>   
                                    <attribute name='fullname'/>  
                                      </entity>   
                            </fetch>";

            EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetch));
            if (result.Entities.Count > 0)
            {
                foreach (var c in result.Entities)
                {
                    System.Console.WriteLine(c.Attributes["fullname"]);
                }
            }
            else
            {
                System.Console.WriteLine("No Results Found");
            }


        }
    }
}
