﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http.Headers;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIDemo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Set these values:
            // e.g. https://yourorg.crm.dynamics.com
            string url = "https://safexdohaqa.crm4.dynamics.com";
            // e.g. you@yourorg.onmicrosoft.com
            string userName = "admin@safexdohaqa.onmicrosoft.com";
            // e.g. y0urp455w0rd
            string password = "Safex12345";

            // Azure Active Directory registered app clientid for Microsoft samples
            string clientId = "5403b1aa-f7f5-436c-be8d-ef2b29f0f17b";

            var userCredential = new UserCredential(userName, password);
            string apiVersion = "9.1";
            string webApiUrl = $"{url}/api/data/v{apiVersion}/";

            //Authenticate using IdentityModel.Clients.ActiveDirectory
            var authParameters = AuthenticationParameters.CreateFromResourceUrlAsync(new Uri(webApiUrl)).Result;
            var authContext = new AuthenticationContext(authParameters.Authority, false);
            var authResult = authContext.AcquireToken(url, clientId, userCredential);
            var authHeader = new AuthenticationHeaderValue("Bearer", authResult.AccessToken);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(webApiUrl);
                client.DefaultRequestHeaders.Authorization = authHeader;

                // Use the WhoAmI function
                var response = client.GetAsync("WhoAmI").Result;

                if (response.IsSuccessStatusCode)
                {
                    //Get the response content and parse it.  
                    JObject body = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    Guid userId = (Guid)body["UserId"];
                    Console.WriteLine("Your UserId is {0}", userId);
                }
                else
                {
                    Console.WriteLine("The request failed with a status of '{0}'",
                                response.ReasonPhrase);
                }
                 CreateRecord(client);
                Console.WriteLine("Press any key to exit.");
                Console.ReadLine();
            }
        }

        private static async Task CreateRecord(HttpClient httpClient)
        {
            JObject contact1 = new JObject{
                        { "firstname", "Demo" },
                        { "lastname", "Contact" },
                        { "annualincome", 100000 }
                        };

            contact1["jobtitle"] = "Junior Developer";
           
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "contacts")
            {
                Content = new StringContent(contact1.ToString(), Encoding.UTF8, "application/json")
            };

            HttpResponseMessage response = await httpClient.SendAsync(request);
            if (response.StatusCode == HttpStatusCode.NoContent)
            //204
            {
                Console.WriteLine("POST succeeded, entity created!");
                //optionally process response message headers or body here, for example:
                var entityUri = response.Headers.GetValues("OData - EntityId").FirstOrDefault();
            }
            else
            {
                Console.WriteLine("Operation failed: {0}", response.ReasonPhrase);
            }
        }
    }
}
