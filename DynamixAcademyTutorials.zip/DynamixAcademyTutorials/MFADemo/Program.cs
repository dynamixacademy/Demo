﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;

namespace MFADemo
{
    class Program
    {
        static void Main(string[] args)
        {
            IOrganizationService organizationService = null;

            try
            {
                string connectionString = @"AuthType=Office365; Url=https://dynx2020.crm8.dynamics.com/;Username=demo@dynx2020.onmicrosoft.com;Password=jsysxvssjmdmhhxn";
                CrmServiceClient crmServiceClient = new CrmServiceClient(connectionString);

                organizationService = crmServiceClient.OrganizationWebProxyClient ?? (IOrganizationService)crmServiceClient.OrganizationServiceProxy;


                if (organizationService != null)
                {
                    Console.WriteLine("Connection Successful!");
                    RetriveContact(organizationService);
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught - " + ex.Message);
            }
            Console.ReadKey();
        }

        public static void RetriveContact(IOrganizationService _service)
        {

            string fetch = @"  
                            <fetch mapping='logical'>  
                                <entity name='contact'>   
                                    <attribute name='contactid'/>   
                                    <attribute name='fullname'/>  
                                      </entity>   
                            </fetch>";

            EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetch));
            if (result.Entities.Count > 0)
            {
                foreach (var c in result.Entities)
                {
                    System.Console.WriteLine(c.Attributes["fullname"]);
                }
            }
            else
            {
                System.Console.WriteLine("No Results Found");
            }


        }
    }
}
